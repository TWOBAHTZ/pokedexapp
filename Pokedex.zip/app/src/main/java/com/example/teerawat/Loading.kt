package com.example.teerawat

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import android.widget.ProgressBar

class Loading : AppCompatActivity() {
    private lateinit var progressBar: ProgressBar
    private val progressUpdateInterval = 50L // เวลาระหว่างการอัปเดต (ms)
    private val totalDuration = 3000L // ระยะเวลารวม (ms)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_loading)

        progressBar = findViewById(R.id.progressBar)

        // เริ่มการเพิ่ม ProgressBar
        startProgressBar()
    }

    private fun startProgressBar() {
        val handler = Handler(Looper.getMainLooper())
        val steps = totalDuration / progressUpdateInterval
        var progress = 0

        val updateTask = object : Runnable {
            override fun run() {
                progress++
                progressBar.progress = (progress * 100 / steps).toInt()

                if (progress < steps) {
                    handler.postDelayed(this, progressUpdateInterval)
                } else {
                    // เมื่อ ProgressBar เต็มแล้ว เปิดหน้า MainActivity
                    val intent = Intent(this@Loading, LoginActivity::class.java)
                    startActivity(intent)
                    finish()
                }
            }
        }

        handler.post(updateTask)
    }
}