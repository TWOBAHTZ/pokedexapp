package com.example.teerawat

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class PokemonListActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: PokemonAdapter
    private lateinit var pokemonList: List<Pokemon>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pokemon_list)

        // ดึงข้อมูลโปเกม่อนจากฐานข้อมูล
        val dbHelper = PokemonDatabaseHelper(this)
        pokemonList = dbHelper.getAllPokemon() // ฟังก์ชันสำหรับดึงโปเกม่อนทั้งหมดจากฐานข้อมูล

        // ตั้งค่า RecyclerView
        recyclerView = findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)
        adapter = PokemonAdapter(pokemonList, this)
        recyclerView.adapter = adapter
    }
}
