package com.example.teerawat

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class PokemonDatabaseHelper(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_NAME = "pokemon_db"
        private const val DATABASE_VERSION = 1
        const val TABLE_NAME = "pokemon"
        const val COLUMN_ID = "id"
        const val COLUMN_NAME = "name"
        const val COLUMN_TYPE = "type"
    }

    override fun onCreate(db: SQLiteDatabase) {
        val createTableQuery = "CREATE TABLE $TABLE_NAME (" +
                "$COLUMN_ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "$COLUMN_NAME TEXT, " +
                "$COLUMN_TYPE TEXT)"
        db.execSQL(createTableQuery)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE_NAME")
        onCreate(db)
    }

    fun getAllPokemon(): List<Pokemon> {
        val pokemonList = mutableListOf<Pokemon>()
        val db = readableDatabase
        val cursor = db.rawQuery("SELECT * FROM pokemon", null)

        if (cursor.moveToFirst()) {
            do {
                val id = cursor.getInt(cursor.getColumnIndexOrThrow("id"))
                val name = cursor.getString(cursor.getColumnIndexOrThrow("name"))
                val type = cursor.getString(cursor.getColumnIndexOrThrow("type"))
                pokemonList.add(Pokemon(id, name, type))
            } while (cursor.moveToNext())
        }
        cursor.close()
        return pokemonList
    }

    // ฟังก์ชันเพิ่มโปเกม่อน
    fun insertPokemon(name: String, type: String): Long {
        val db = writableDatabase
        val values = ContentValues().apply {
            put(COLUMN_NAME, name)
            put(COLUMN_TYPE, type)
        }
        return db.insert(TABLE_NAME, null, values)
    }

    // ฟังก์ชันลบโปเกม่อน
    fun deletePokemon(id: Int): Int {
        val db = writableDatabase
        return db.delete(TABLE_NAME, "$COLUMN_ID=?", arrayOf(id.toString()))
    }

    // ฟังก์ชันค้นหาโปเกม่อนตามชื่อ
    fun searchPokemon(query: String): List<Pokemon> {
        val pokemonList = mutableListOf<Pokemon>()
        val db = readableDatabase
        val searchQuery = "SELECT * FROM pokemon WHERE name LIKE ? OR type LIKE ?"
        val cursor = db.rawQuery(searchQuery, arrayOf("%$query%", "%$query%"))

        if (cursor.moveToFirst()) {
            do {
                val id = cursor.getInt(cursor.getColumnIndexOrThrow("id"))
                val name = cursor.getString(cursor.getColumnIndexOrThrow("name"))
                val type = cursor.getString(cursor.getColumnIndexOrThrow("type"))
                pokemonList.add(Pokemon(id, name, type))
            } while (cursor.moveToNext())
        }
        cursor.close()
        return pokemonList
    }


    fun getPokemonById(id: Int): Pokemon? {
        val db = readableDatabase
        val query = "SELECT * FROM pokemon WHERE id = ?"
        val cursor = db.rawQuery(query, arrayOf(id.toString()))

        return if (cursor.moveToFirst()) {
            val name = cursor.getString(cursor.getColumnIndexOrThrow("name"))
            val type = cursor.getString(cursor.getColumnIndexOrThrow("type"))
            Pokemon(id, name, type)
        } else {
            null
        }.also {
            cursor.close()
        }
    }

    fun updatePokemon(id: Int, newName: String, newType: String): Boolean {
        val db = writableDatabase
        val values = ContentValues().apply {
            put("name", newName)
            put("type", newType)
        }
        val updatedRows = db.update("pokemon", values, "id = ?", arrayOf(id.toString()))
        return updatedRows > 0
    }


}
