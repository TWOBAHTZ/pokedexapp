package com.example.teerawat

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class SearchActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: PokemonAdapter
    private lateinit var searchInput: EditText
    private lateinit var searchButton: Button
    private lateinit var dbHelper: PokemonDatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_search)

        // เชื่อมโยง View
        searchInput = findViewById(R.id.etSearchInput)
        searchButton = findViewById(R.id.btnSearch)
        recyclerView = findViewById(R.id.recyclerViewSearch)
        recyclerView.layoutManager = LinearLayoutManager(this)

        // ตั้งค่า Database Helper
        dbHelper = PokemonDatabaseHelper(this)

        // ตั้งค่า OnClickListener สำหรับปุ่มค้นหา
        searchButton.setOnClickListener {
            val query = searchInput.text.toString().trim()
            if (query.isNotEmpty()) {
                searchPokemon(query)
            } else {
                Toast.makeText(this, "Please enter a search term", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun searchPokemon(query: String) {
        val searchResults = dbHelper.searchPokemon(query)

        if (searchResults.isNotEmpty()) {
            adapter = PokemonAdapter(searchResults, this)
            recyclerView.adapter = adapter
        } else {
            Toast.makeText(this, "No Pokémon found", Toast.LENGTH_SHORT).show()
        }
    }
}
