package com.example.teerawat

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.Button

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        findViewById<Button>(R.id.btnPokemonList).setOnClickListener {
            startActivity(Intent(this, PokemonListActivity::class.java))
        }

        findViewById<Button>(R.id.btnAddPokemon).setOnClickListener {
            startActivity(Intent(this, AddPokemonActivity::class.java))
        }

        findViewById<Button>(R.id.btnSearchPokemon).setOnClickListener {
            startActivity(Intent(this, SearchActivity::class.java))
        }
    }
}