package com.example.teerawat

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class AddPokemonActivity : AppCompatActivity() {

    private lateinit var dbHelper: PokemonDatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_pokemon)

        dbHelper = PokemonDatabaseHelper(this)

        val etPokemonName = findViewById<EditText>(R.id.etPokemonName)
        val etPokemonType = findViewById<EditText>(R.id.etPokemonType)
        val btnAddPokemon = findViewById<Button>(R.id.btnSavePokemon)

        // ปุ่มสำหรับเพิ่มโปเกม่อน
        btnAddPokemon.setOnClickListener {
            val name = etPokemonName.text.toString()
            val type = etPokemonType.text.toString()

            if (name.isNotEmpty() && type.isNotEmpty()) {
                val result = dbHelper.insertPokemon(name, type)
                if (result != -1L) {
                    Toast.makeText(this, "$name added successfully!", Toast.LENGTH_SHORT).show()
                    finish() // กลับไปยัง PokemonListActivity
                } else {
                    Toast.makeText(this, "Failed to add $name", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "Please enter both name and type", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
