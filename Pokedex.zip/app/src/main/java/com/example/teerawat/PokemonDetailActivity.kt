package com.example.teerawat

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class PokemonDetailActivity : AppCompatActivity() {

    private lateinit var editName: EditText
    private lateinit var editType: EditText
    private lateinit var editButton: Button
    private lateinit var dbHelper: PokemonDatabaseHelper
    private var pokemonId: Int = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pokemon_detail)

        // เชื่อมโยง View
        editName = findViewById(R.id.editPokemonName)
        editType = findViewById(R.id.editPokemonType)
        editButton = findViewById(R.id.btnEdit)

        // ตั้งค่า Database Helper
        dbHelper = PokemonDatabaseHelper(this)

        // รับ ID ของโปเกม่อนจาก Intent
        pokemonId = intent.getIntExtra("POKEMON_ID", -1)
        if (pokemonId == -1) {
            Toast.makeText(this, "Error: No Pokemon ID provided", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        // ดึงข้อมูลโปเกม่อนจากฐานข้อมูล
        val pokemon = dbHelper.getPokemonById(pokemonId)
        if (pokemon != null) {
            // แสดงข้อมูลใน EditText
            editName.setText(pokemon.name)
            editType.setText(pokemon.type)
        } else {
            Toast.makeText(this, "Pokemon not found", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        // ตั้งค่า OnClickListener สำหรับปุ่ม Edit
        editButton.setOnClickListener {
            val newName = editName.text.toString().trim()
            val newType = editType.text.toString().trim()

            if (newName.isNotEmpty() && newType.isNotEmpty()) {
                val updated = dbHelper.updatePokemon(pokemonId, newName, newType)
                if (updated) {
                    Toast.makeText(this, "Pokemon updated successfully", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "Failed to update Pokemon", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "Name and Type cannot be empty", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
